library(bupaR)
library(daqapo)

## geting the new data sets into R

logged_in <- read.csv(file.path("C:\\Users\\sina\\Desktop\\data sets\\new2\\logged_in_final.csv"), header = TRUE)

## cleaning extra columns
logged_in <- subset(logged_in, select = c("CustomerID", "Activity", "complete", "AgeCategory", "Gender") )


logged_in$complete<- as.POSIXct(logged_in$complete,tz=Sys.timezone())


## converting the data sets to eventlogs

logged_in <- simple_eventlog(eventlog = logged_in, case_id = "CustomerID",
                           timestamp = "complete", 
                           activity_id = "Activity",
                           resource_id = c("AgeCategory","Gender"))
length(unique(logged_in$AgeCategory_Gender))
## filtering  cases based on gender and age
F_18_29 <- subset(logged_in, AgeCategory_Gender == "18-29_V")
F_30_39 <- subset(logged_in, AgeCategory_Gender == "30-39_V")
F_40_49 <- subset(logged_in, AgeCategory_Gender == "40-49_V")
F_50_65 <- subset(logged_in, AgeCategory_Gender == "50-65_V")
M_18_29 <- subset(logged_in, AgeCategory_Gender == "18-29_M")
M_30_39 <- subset(logged_in, AgeCategory_Gender == "30-39_M")
M_40_49 <- subset(logged_in, AgeCategory_Gender == "40-49_M")
M_50_65 <- subset(logged_in, AgeCategory_Gender == "50-65_M")

length(unique(F_18_29$CustomerID))
length(unique(F_30_39$CustomerID))
length(unique(F_40_49$CustomerID))
length(unique(F_50_65$CustomerID))
length(unique(M_18_29$CustomerID))
length(unique(M_30_39$CustomerID))
length(unique(M_40_49$CustomerID))
length(unique(M_50_65$CustomerID))
