## geting the new data sets into R
all_logged_in_traces <- read.csv(file.path("C:\\Users\\sina\\Desktop\\data sets\\new", "all_logged_in_traces.csv"), head = TRUE, )
all_not_logged_in_traces <- read.csv(file.path("C:\\Users\\sina\\Desktop\\data sets\\new", "all_not_logged_in_traces.csv"), head = TRUE)
all_logged_in_traces <- subset(all_logged_in_traces, select = -X)
all_not_logged_in_traces <- subset(all_not_logged_in_traces, select = -X)
all_logged_in_traces$TIMESTAMP <- as.POSIXct(all_logged_in_traces$TIMESTAMP,tz=Sys.timezone())
all_not_logged_in_traces$TIMESTAMP <- as.POSIXct(all_not_logged_in_traces$TIMESTAMP,tz=Sys.timezone())

install.packages("bupaR")
install.packages("eventdataR")
install.packages("xesreadR") 
install.packages("edeaR") 
install.packages("processmapR") 
install.packages("processmonitR")
library(bupaR)
library(daqapo)
logged_in_event_log <- simple_eventlog(eventlog = all_logged_in_traces, case_id = "CustomerID",
                                       timestamp = "TIMESTAMP", 
                                       activity_id = "Activity")
not_logged_in_event_log <- simple_eventlog(eventlog = all_not_logged_in_traces, case_id = "CustomerID",
                                           timestamp = "TIMESTAMP", 
                                           activity_id = "Activity")

newTABLE <- filter_throughput_time(logged_in_event_log, interval = c(2,NA), units = "days")
newTABLE2 <- filter_throughput_time(not_logged_in_event_log, interval = c(2,NA), units = "days")

length(unique(logged_in_event_log$CustomerID))
length(unique(newTABLE$CustomerID))
length(unique(not_logged_in_event_log$CustomerID))
length(unique(newTABLE2$CustomerID))



newTABLE$lifecycle_id <- "complete"
newTABLE2$lifecycle_id <- "complete"

data1 <- events_to_activitylog(
  newTABLE,
  case_id = "CustomerID",
  activity_id = "Activity",
  activity_instance_id = "avtivity_instance_id",
  lifecycle_id = "lifecycle_id",
  timestamp = "TIMESTAMP",
  resource_id = "Theme"
)
data2<- subset(data1, Activity != "complaint" & Activity != "Phone Call" & Activity != "Message")
data3 <- subset(data1, Activity == "complaint"| Activity == "Phone Call"| Activity == "Message")

data4 <- filter_anomalies(data2, 
                          detect_multiregistration(data2, level_of_aggregation = "case", 
                                                   timestamp = "complete" , threshold_in_seconds = 35))
logged_in_final <- rbind(data3, data4)
logged_in_final <-as.data.frame(logged_in_final)
logged_in_final <- simple_eventlog(logged_in_final,case_id = "CustomerID",
                                   timestamp = "complete", 
                                   activity_id = "Activity" )

data5  <- events_to_activitylog(
  newTABLE2,
  case_id = "CustomerID",
  activity_id = "Activity",
  activity_instance_id = "avtivity_instance_id",
  lifecycle_id = "lifecycle_id",
  timestamp = "TIMESTAMP",
  resource_id = "resourse_id"
)
data6 <- filter_anomalies(data5, 
                          detect_multiregistration(data5, level_of_aggregation = "case", 
                                                   timestamp = "complete" , threshold_in_seconds = 60))

not_logged_in_final <-as.data.frame(data6)
not_logged_in_final <- simple_eventlog(not_logged_in_final,case_id = "CustomerID",
                                   timestamp = "complete", 
                                   activity_id = "Activity" )


logged_in_less_than_3_months <- filter_throughput_time(logged_in_final, interval = c(NA,90), units = "days")
logged_in_more_than_3_months <- filter_throughput_time(logged_in_final, interval = c(90,NA), units = "days")
length(unique(logged_in_final$CustomerID))
length(unique(logged_in_less_than_3_months$CustomerID))
length(unique(logged_in_more_than_3_months$CustomerID))

not_logged_in_less_than_3_months <- filter_throughput_time(not_logged_in_final, interval = c(NA,90), units = "days")
not_logged_in_more_than_3_months <- filter_throughput_time(not_logged_in_final, interval = c(90,NA), units = "days")
length(unique(not_logged_in_final$CustomerID))
length(unique(not_logged_in_less_than_3_months$CustomerID))
length(unique(not_logged_in_more_than_3_months$CustomerID))

write.csv(not_logged_in_final,"C:\\Users\\sina\\Desktop\\data sets\\new2\\not_logged_in_final.csv", row.names = TRUE)
write.csv(not_logged_in_more_than_3_months,"C:\\Users\\sina\\Desktop\\data sets\\new2\\not_logged_in_more_than_3_months.csv", row.names = TRUE)
write.csv(not_logged_in_less_than_3_months,"C:\\Users\\sina\\Desktop\\data sets\\new2\\not_logged_in_less_than_3_months.csv", row.names = TRUE)

write.csv(logged_in_final,"C:\\Users\\sina\\Desktop\\data sets\\new2\\logged_in_final.csv", row.names = TRUE)
write.csv(logged_in_more_than_3_months,"C:\\Users\\sina\\Desktop\\data sets\\new2\\logged_in_more_than_3_months.csv", row.names = TRUE)
write.csv(logged_in_less_than_3_months,"C:\\Users\\sina\\Desktop\\data sets\\new2\\logged_in_less_than_3_months.csv", row.names = TRUE)
