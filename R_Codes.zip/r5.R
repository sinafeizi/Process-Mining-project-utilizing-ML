library(bupaR)
library(daqapo)
library(dplyr)
## geting the new data sets into R

logged_in <- read.csv(file.path("C:\\Users\\sina\\Desktop\\data sets\\new2\\logged_in_final.csv"), header = TRUE)

## cleaning extra columns
logged_in <- subset(logged_in, select = c("CustomerID", "Activity", "complete" ))
logged_in$complete<- as.POSIXct(logged_in$complete,tz=Sys.timezone())

## converting the data sets to eventlogs

logged_in <- simple_eventlog(eventlog = logged_in, case_id = "CustomerID",
                             timestamp = "complete", 
                             activity_id = "Activity")
library(lubridate)
## dividing cases based on time into 4 sequential 2-months periods 


the_1st_2months <- filter_time_period(logged_in, interval = ymd(c(20150701, 20150901)), filter_method = "trim")

the_2nd_2months <- filter_time_period(logged_in, interval = ymd(c(20150901, 20151101)), filter_method = "trim")

the_3rd_2months <- filter_time_period(logged_in, interval = ymd(c(20151101, 20160101)), filter_method = "trim")

the_4th_2months <- filter_time_period(logged_in, interval = ymd(c(20160102, 20160229)), filter_method = "trim")

plot(top_n(activity_presence(the_1st_2months), n=10))

plot(top_n(activity_presence(the_2nd_2months), n=10))

plot(top_n(activity_presence(the_3rd_2months), n=10))

plot(top_n(activity_presence(the_4th_2months), n=10))

the_1st_2months_s <- filter_activity_frequency(the_1st_2months, percentage = 0.65, reverse = F)

the_2nd_2months_s <- filter_activity_frequency(the_2nd_2months, percentage = 0.65, reverse = F)

the_3rd_2months_s <- filter_activity_frequency(the_3rd_2months, percentage = 0.65, reverse = F)

the_4th_2months_s <- filter_activity_frequency(the_4th_2months, percentage = 0.65, reverse = F)

process_map(the_1st_2months_s, type_nodes = frequency("relative_case"))

process_map(the_2nd_2months_s, type_nodes = frequency("relative_case"))

process_map(the_3rd_2months_s, type_nodes = frequency("relative_case"))

process_map(the_4th_2months_s, type_nodes = frequency("relative_case"))
