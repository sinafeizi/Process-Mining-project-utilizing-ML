library(lubridate)
library(bupaR)
library(daqapo)
library(dplyr)
## geting the new data sets into R

logged_in <- read.csv(file.path("C:\\Users\\sina\\Desktop\\data sets\\new2\\logged_in_final.csv"), header = TRUE)

## cleaning extra columns
logged_in <- subset(logged_in, select = c("CustomerID", "Activity", "complete","AgeCategory", "Gender", "Theme", "Subtheme", "Topic" ))
logged_in$complete<- as.POSIXct(logged_in$complete,tz=Sys.timezone())

## converting the data sets to eventlogs

logged_in <- simple_eventlog(eventlog = logged_in, case_id = "CustomerID",
                             timestamp = "complete", 
                             activity_id = "Activity", resource_id = c("Gender","AgeCategory"))
all_complaints <- filter_activity(logged_in, activities = "complaint" )
## filtering  cases based on gender and age
F_18_29 <- subset(all_complaints, Gender_AgeCategory == "V_18-29")
F_30_39 <- subset(all_complaints, Gender_AgeCategory == "V_30-39")
F_40_49 <- subset(all_complaints, Gender_AgeCategory == "V_40-49")
F_50_65 <- subset(all_complaints, Gender_AgeCategory == "V_50-65")
M_18_29 <- subset(all_complaints, Gender_AgeCategory == "M_18-29")
M_30_39 <- subset(all_complaints, Gender_AgeCategory == "M_30-39")
M_40_49 <- subset(all_complaints, Gender_AgeCategory == "M_40-49")
M_50_65 <- subset(all_complaints, Gender_AgeCategory == "M_50-65")

length(unique(F_18_29$CustomerID))
length(unique(F_30_39$CustomerID))
length(unique(F_40_49$CustomerID))
length(unique(F_50_65$CustomerID))
length(unique(M_18_29$CustomerID))
length(unique(M_30_39$CustomerID))
length(unique(M_40_49$CustomerID))
length(unique(M_50_65$CustomerID))

complainted_users <- filter_activity_presence(logged_in, activities = "complaint" )
complainted_users <- filter_activity_frequency(complainted_users,percentage = 0.65, reverse = F)
process_map(complainted_users)
