library(lubridate)
library(bupaR)
library(daqapo)
library(dplyr)
## geting the new data sets into R

logged_in <- read.csv(file.path("C:\\Users\\sina\\Desktop\\data sets\\new2\\logged_in_final.csv"), header = TRUE)

## cleaning extra columns
logged_in <- subset(logged_in, select = c("CustomerID", "Activity", "complete","AgeCategory", "Gender" ))
logged_in$complete<- as.POSIXct(logged_in$complete,tz=Sys.timezone())

## converting the data sets to eventlogs

logged_in <- simple_eventlog(eventlog = logged_in, case_id = "CustomerID",
                             timestamp = "complete", 
                             activity_id = "Activity", resource_id = c("Gender","AgeCategory"))
##dividing all events into 8 sex and age categories

F_18_29 <- subset(logged_in, logged_in$Gender_AgeCategory== "V_18-29")
F_30_39 <- subset(logged_in, logged_in$Gender_AgeCategory== "V_30-39")
F_40_49 <- subset(logged_in, logged_in$Gender_AgeCategory== "V_40-49")
F_50_65 <- subset(logged_in, logged_in$Gender_AgeCategory== "V_50-65")

M_18_29 <- subset(logged_in, logged_in$Gender_AgeCategory== "M_18-29")
M_30_39 <- subset(logged_in, logged_in$Gender_AgeCategory== "M_30-39")
M_40_49 <- subset(logged_in, logged_in$Gender_AgeCategory== "M_40-49")
M_50_65 <- subset(logged_in, logged_in$Gender_AgeCategory== "M_50-65")

##filtering cases who did use ALL expensive channels
F_18_29_all <- filter_activity_presence(F_18_29, activities = c("Phone Call","complaint", "Message"))
length(unique(F_18_29_all$CustomerID))
F_30_39_all <- filter_activity_presence(F_30_39, activities = c("Phone Call","complaint", "Message"))
length(unique(F_30_39_all$CustomerID))
F_40_49_all <- filter_activity_presence(F_40_49, activities = c("Phone Call","complaint", "Message"))
length(unique(F_40_49_all$CustomerID))
F_50_65_all <- filter_activity_presence(F_50_65, activities = c("Phone Call","complaint", "Message"))
length(unique(F_50_65_all$CustomerID))

M_18_29_all <- filter_activity_presence(M_18_29, activities = c("Phone Call","complaint", "Message"))
length(unique(M_18_29_all$CustomerID))
M_30_39_all <- filter_activity_presence(M_30_39, activities = c("Phone Call","complaint", "Message"))
length(unique(M_30_39_all$CustomerID))
M_40_49_all <- filter_activity_presence(M_40_49, activities = c("Phone Call","complaint", "Message"))
length(unique(M_40_49_all$CustomerID))
M_50_65_all <- filter_activity_presence(M_50_65, activities = c("Phone Call","complaint", "Message"))
length(unique(M_50_65_all$CustomerID))

##filtering cases who ONLY used Messages and Calls
F_18_29_MC <- filter_activity_presence(F_18_29, activities = c("Phone Call", "Message"))
F_18_29_MC <- filter_activity_presence(F_18_29_MC, activities = c("complaint"), reverse = T)
length(unique(F_18_29_MC$CustomerID))
F_30_39_MC <- filter_activity_presence(F_30_39, activities = c("Phone Call", "Message"))
F_30_39_MC <- filter_activity_presence(F_30_39_MC, activities = c("complaint"), reverse = T)
length(unique(F_30_39_MC$CustomerID))
F_40_49_MC <- filter_activity_presence(F_40_49, activities = c("Phone Call", "Message"))
F_40_49_MC <- filter_activity_presence(F_40_49_MC, activities = c("complaint"), reverse = T)
length(unique(F_40_49_MC$CustomerID))
F_50_65_MC <- filter_activity_presence(F_50_65, activities = c("Phone Call", "Message"))
F_50_65_MC <- filter_activity_presence(F_50_65_MC, activities = c("complaint"), reverse = T)
length(unique(F_50_65_MC$CustomerID))

M_18_29_MC <- filter_activity_presence(M_18_29, activities = c("Phone Call", "Message"))
M_18_29_MC <- filter_activity_presence(M_18_29_MC, activities = c("complaint"), reverse = T)
length(unique(M_18_29_MC$CustomerID))
M_30_39_MC <- filter_activity_presence(M_30_39, activities = c("Phone Call", "Message"))
M_30_39_MC <- filter_activity_presence(M_30_39_MC, activities = c("complaint"), reverse = T)
length(unique(M_30_39_MC$CustomerID))
M_40_49_MC <- filter_activity_presence(M_40_49, activities = c("Phone Call", "Message"))
M_40_49_MC <- filter_activity_presence(M_40_49_MC, activities = c("complaint"), reverse = T)
length(unique(M_40_49_MC$CustomerID))
M_50_65_MC <- filter_activity_presence(M_50_65, activities = c("Phone Call", "Message"))
M_50_65_MC <- filter_activity_presence(M_50_65_MC, activities = c("complaint"), reverse = T)
length(unique(M_50_65_MC$CustomerID))

##filtering cases who ONLY used Calls and Complaint
F_18_29_CC <- filter_activity_presence(F_18_29, activities = c("Phone Call", "complaint"))
F_18_29_CC <- filter_activity_presence(F_18_29_CC, activities = c("Message"), reverse = T)
length(unique(F_18_29_CC$CustomerID))
F_30_39_CC <- filter_activity_presence(F_30_39, activities = c("Phone Call", "complaint"))
F_30_39_CC <- filter_activity_presence(F_30_39_CC, activities = c("Message"), reverse = T)
length(unique(F_30_39_CC$CustomerID))
F_40_49_CC <- filter_activity_presence(F_40_49, activities = c("Phone Call", "complaint"))
F_40_49_CC <- filter_activity_presence(F_40_49_CC, activities = c("Message"), reverse = T)
length(unique(F_40_49_CC$CustomerID))
F_50_65_CC <- filter_activity_presence(F_50_65, activities = c("Phone Call", "complaint"))
F_50_65_CC <- filter_activity_presence(F_50_65_CC, activities = c("Message"), reverse = T)
length(unique(F_50_65_CC$CustomerID))

M_18_29_CC <- filter_activity_presence(M_18_29, activities = c("Phone Call", "complaint"))
M_18_29_CC <- filter_activity_presence(M_18_29_CC, activities = c("Message"), reverse = T)
length(unique(M_18_29_CC$CustomerID))
M_30_39_CC <- filter_activity_presence(M_30_39, activities = c("Phone Call", "complaint"))
M_30_39_CC <- filter_activity_presence(M_30_39_CC, activities = c("Message"), reverse = T)
length(unique(M_30_39_CC$CustomerID))
M_40_49_CC <- filter_activity_presence(M_40_49, activities = c("Phone Call", "complaint"))
M_40_49_CC <- filter_activity_presence(M_40_49_CC, activities = c("Message"), reverse = T)
length(unique(M_40_49_CC$CustomerID))
M_50_65_CC <- filter_activity_presence(M_50_65, activities = c("Phone Call", "complaint"))
M_50_65_CC <- filter_activity_presence(M_50_65_CC, activities = c("Message"), reverse = T)
length(unique(M_50_65_CC$CustomerID))

##filtering cases who ONLY used Complaint and Messages
F_18_29_CM <- filter_activity_presence(F_18_29, activities = c("Message", "complaint"))
F_18_29_CM <- filter_activity_presence(F_18_29_CM, activities = c("Phone Call"), reverse = T)
length(unique(F_18_29_CM$CustomerID))
F_30_39_CM <- filter_activity_presence(F_30_39, activities = c("Message", "complaint"))
F_30_39_CM <- filter_activity_presence(F_30_39_CM, activities = c("Phone Call"), reverse = T)
length(unique(F_30_39_CM$CustomerID))
F_40_49_CM <- filter_activity_presence(F_40_49, activities = c("Message", "complaint"))
F_40_49_CM <- filter_activity_presence(F_40_49_CM, activities = c("Phone Call"), reverse = T)
length(unique(F_40_49_CM$CustomerID))
F_50_65_CM <- filter_activity_presence(F_50_65, activities = c("Message", "complaint"))
F_50_65_CM <- filter_activity_presence(F_50_65_CM, activities = c("Phone Call"), reverse = T)
length(unique(F_50_65_CM$CustomerID))

M_18_29_CM <- filter_activity_presence(M_18_29, activities = c("Message", "complaint"))
M_18_29_CM <- filter_activity_presence(M_18_29_CM, activities = c("Phone Call"), reverse = T)
length(unique(M_18_29_CM$CustomerID))
M_30_39_CM <- filter_activity_presence(M_30_39, activities = c("Message", "complaint"))
M_30_39_CM <- filter_activity_presence(M_30_39_CM, activities = c("Phone Call"), reverse = T)
length(unique(M_30_39_CM$CustomerID))
M_40_49_CM <- filter_activity_presence(M_40_49, activities = c("Message", "complaint"))
M_40_49_CM <- filter_activity_presence(M_40_49_CM, activities = c("Phone Call"), reverse = T)
length(unique(M_40_49_CM$CustomerID))
M_50_65_CM <- filter_activity_presence(M_50_65, activities = c("Message", "complaint"))
M_50_65_CM <- filter_activity_presence(M_50_65_CM, activities = c("Phone Call"), reverse = T)
length(unique(M_50_65_CM$CustomerID))

## filtering expensive activities individualy

all_complaints <- filter_activity(logged_in, activities = "complaint" )
hist(all_complaints$complete, breaks = "days")

all_calls <- filter_activity(logged_in, activities = "Phone Call" )
hist(all_calls$complete, breaks = "days")

all_messages <- filter_activity(logged_in, activities = "Message" )
hist(all_messages$complete, breaks = "days")
