library(bupaR)
library(daqapo)

## geting the new data sets into R

not_logged_in <- read.csv(file.path("C:\\Users\\sina\\Desktop\\data sets\\new2\\not_logged_in_final.csv"), header =  TRUE)
not_logged_in_more_than_3 <- read.csv(file.path("C:\\Users\\sina\\Desktop\\data sets\\new2\\not_logged_in_more_than_3_months.csv"), header =  TRUE)
not_logged_in_less_than_3 <- read.csv(file.path("C:\\Users\\sina\\Desktop\\data sets\\new2\\not_logged_in_less_than_3_months.csv"), header =  TRUE)

logged_in <- read.csv(file.path("C:\\Users\\sina\\Desktop\\data sets\\new2\\logged_in_final.csv"), header = TRUE)
logged_in_more_than_3 <- read.csv(file.path("C:\\Users\\sina\\Desktop\\data sets\\new2\\logged_in_more_than_3_months.csv"), header = TRUE)
logged_in_less_than_3 <-read.csv(file.path("C:\\Users\\sina\\Desktop\\data sets\\new2\\logged_in_less_than_3_months.csv"), header = TRUE)

## cleaning extra columns
logged_in <- subset(logged_in, select = c("CustomerID", "Activity", "complete") )
logged_in_less_than_3 <- subset(logged_in_less_than_3, select =c("CustomerID", "Activity", "complete") )
logged_in_more_than_3 <- subset(logged_in_more_than_3, select = c("CustomerID", "Activity", "complete") )
not_logged_in <- subset(not_logged_in, select = c("CustomerID", "Activity", "complete") )
not_logged_in_less_than_3 <- subset(not_logged_in_less_than_3, select = c("CustomerID", "Activity", "complete") )
not_logged_in_more_than_3 <- subset(not_logged_in_more_than_3, select = c("CustomerID", "Activity", "complete") )

alldata <- rbind(logged_in, not_logged_in)
all_more_3 <- rbind(logged_in_more_than_3, not_logged_in_more_than_3)
all_less_3 <- rbind(logged_in_less_than_3, not_logged_in_less_than_3)

alldata$complete<- as.POSIXct(alldata$complete,tz=Sys.timezone())
all_more_3$complete<- as.POSIXct(all_more_3$complete,tz=Sys.timezone())
all_less_3$complete<- as.POSIXct(all_less_3$complete,tz=Sys.timezone())

## converting all 3 main data sets to eventlogs

alldata <- simple_eventlog(eventlog = alldata, case_id = "CustomerID",
                                       timestamp = "complete", 
                                       activity_id = "Activity")
all_more_3 <- simple_eventlog(eventlog = all_more_3, case_id = "CustomerID",
                           timestamp = "complete", 
                           activity_id = "Activity")
all_less_3 <- simple_eventlog(eventlog = all_less_3, case_id = "CustomerID",
                           timestamp = "complete", 
                           activity_id = "Activity")
## filtering active cases
all_1st_month <- filter_time_period(alldata, interval = ymd(c(20150701, 20150801)), filter_method = "intersecting")
length(unique(all_1st_month$CustomerID))
all_2nd_month <- filter_time_period(alldata, interval = ymd(c(20150801, 20150901)), filter_method = "intersecting")
length(unique(all_2nd_month$CustomerID))
all_3rd_month <- filter_time_period(alldata, interval = ymd(c(20150901, 20151001)), filter_method = "intersecting")
length(unique(all_3rd_month$CustomerID))
all_4rd_month <- filter_time_period(alldata, interval = ymd(c(20151001, 20151101)), filter_method = "intersecting")
length(unique(all_4rd_month$CustomerID))
all_5rd_month <- filter_time_period(alldata, interval = ymd(c(20151101, 20151201)), filter_method = "intersecting")
length(unique(all_5rd_month$CustomerID))
all_6th_month <- filter_time_period(alldata, interval = ymd(c(20151201, 20160101)), filter_method = "intersecting")
length(unique(all_6th_month$CustomerID))
all_7th_month <- filter_time_period(alldata, interval = ymd(c(20160101, 20160201)), filter_method = "intersecting")
length(unique(all_7th_month$CustomerID))
all_8th_month <- filter_time_period(alldata, interval = ymd(c(20160201, 20160229)), filter_method = "intersecting")
length(unique(all_8th_month$CustomerID))

## filtering active cases (more than 3 months)
allmore3_1st_month <- filter_time_period(all_more_3, interval = ymd(c(20150701, 20150801)), filter_method = "intersecting")
length(unique(allmore3_1st_month$CustomerID))
allmore3_2nd_month <- filter_time_period(all_more_3, interval = ymd(c(20150801, 20150901)), filter_method = "intersecting")
length(unique(allmore3_2nd_month$CustomerID))
allmore3_3rd_month <- filter_time_period(all_more_3, interval = ymd(c(20150901, 20151001)), filter_method = "intersecting")
length(unique(allmore3_3rd_month$CustomerID))
allmore3_4rd_month <- filter_time_period(all_more_3, interval = ymd(c(20151001, 20151101)), filter_method = "intersecting")
length(unique(allmore3_4rd_month$CustomerID))
allmore3_5rd_month <- filter_time_period(all_more_3, interval = ymd(c(20151101, 20151201)), filter_method = "intersecting")
length(unique(allmore3_5rd_month$CustomerID))
allmore3_6th_month <- filter_time_period(all_more_3, interval = ymd(c(20151201, 20160101)), filter_method = "intersecting")
length(unique(allmore3_6th_month$CustomerID))
allmore3_7th_month <- filter_time_period(all_more_3, interval = ymd(c(20160101, 20160201)), filter_method = "intersecting")
length(unique(allmore3_7th_month$CustomerID))
allmore3_8th_month <- filter_time_period(all_more_3, interval = ymd(c(20160201, 20160229)), filter_method = "intersecting")
length(unique(allmore3_8th_month$CustomerID))

## filtering active cases (less than 3 months)
allless3_1st_month <- filter_time_period(all_less_3, interval = ymd(c(20150701, 20150801)), filter_method = "intersecting")
length(unique(allless3_1st_month$CustomerID))
allless3_2nd_month <- filter_time_period(all_less_3, interval = ymd(c(20150801, 20150901)), filter_method = "intersecting")
length(unique(allless3_2nd_month$CustomerID))
allless3_3rd_month <- filter_time_period(all_less_3, interval = ymd(c(20150901, 20151001)), filter_method = "intersecting")
length(unique(allless3_3rd_month$CustomerID))
allless3_4rd_month <- filter_time_period(all_less_3, interval = ymd(c(20151001, 20151101)), filter_method = "intersecting")
length(unique(allless3_4rd_month$CustomerID))
allless3_5rd_month <- filter_time_period(all_less_3, interval = ymd(c(20151101, 20151201)), filter_method = "intersecting")
length(unique(allless3_5rd_month$CustomerID))
allless3_6th_month <- filter_time_period(all_less_3, interval = ymd(c(20151201, 20160101)), filter_method = "intersecting")
length(unique(allless3_6th_month$CustomerID))
allless3_7th_month <- filter_time_period(all_less_3, interval = ymd(c(20160101, 20160201)), filter_method = "intersecting")
length(unique(allless3_7th_month$CustomerID))
allless3_8th_month <- filter_time_period(all_less_3, interval = ymd(c(20160201, 20160229)), filter_method = "intersecting")
length(unique(allless3_8th_month$CustomerID))
