## getting data sets into R
clicks_logged_in <- read.csv(file.path("C:\\Users\\sina\\Desktop\\data sets", "BPI2016_Clicks_Logged_In.csv"), head = TRUE, sep=";")
clicks_not_logged_in <- read.csv(file.path("C:\\Users\\sina\\Desktop\\data sets", "BPI2016_Clicks_NOT_Logged_In.csv"), head = TRUE, sep=";",quote = "")
complaints <- read.csv(file.path("C:\\Users\\sina\\Desktop\\data sets", "BPI2016_Complaints.csv"), head = TRUE, sep=";")
questions <- read.csv(file.path("C:\\Users\\sina\\Desktop\\data sets", "BPI2016_Questions.csv"), head = TRUE, sep=";", quote = "")
werkmap_mes <- read.csv(file.path("C:\\Users\\sina\\Desktop\\data sets", "BPI2016_Werkmap_Messages.csv"), head = TRUE, sep=";")

## simplify clicks logged in
edited_clicks_logged_in <- data.frame(CustomerID = clicks_logged_in$CustomerID,
                                      AgeCategory = clicks_logged_in$AgeCategory, 
                                      Gender = clicks_logged_in$Gender, TIMESTAMP = clicks_logged_in$TIMESTAMP, Activity = clicks_logged_in$PAGE_NAME)
edited_clicks_logged_in$TIMESTAMP <- substr(edited_clicks_logged_in[,4],1,19)
## Simplify complaints
complaints$contact_time <- "00:00:00" ## adding fake times
complaints$TIMESTAMP <- paste(complaints$ContactDate, complaints$contact_time) ## merging date and the fake times
edited_complaints <- data.frame(CustomerID= complaints$CustomerID, 
                                AgeCategory = complaints$AgeCategory, Gender = complaints$Gender, 
                                TIMESTAMP = complaints$TIMESTAMP , Activity = "complaint", Theme = complaints$ComplaintTheme_EN , 
                                Subtheme = complaints$ComplaintSubtheme_EN, Topic = complaints$ComplaintTopic_EN)

## deriving duration of calls from end and start time stamps
##this idea was later scrapped due to not giving any meaningful insight, codes are here:

##question_end_value <- data.frame(questions$ContactTimeEnd)
##question_end_value_hour <- substr(question_end_value[,1],1,2)
##question_end_value_min <- substr(question_end_value[,1],4,5)
##question_end_value_sec <- substr(question_end_value[,1],7,8)
##question_end_value_hour <- as.numeric(question_end_value_hour)
##question_end_value_min <- as.numeric(question_end_value_min)
##question_end_value_sec <- as.numeric(question_end_value_sec)
##question_end_value <- ((question_end_value_hour*3600)+(question_end_value_min*60)+(question_end_value_sec))

##question_start_value <- data.frame(questions$ContactTimeStart)
##question_start_value_hour <- substr(question_start_value[,1],1,2)
##question_start_value_min <- substr(question_start_value[,1],4,5)
##question_start_value_sec <- substr(question_start_value[,1],7,8)
##question_start_value_hour <- as.numeric(question_start_value_hour)
##question_start_value_min <- as.numeric(question_start_value_min)
##question_start_value_sec <- as.numeric(question_start_value_sec)
##question_start_value <- ((question_start_value_hour*3600)+(question_start_value_min*60)+(question_start_value_sec))

##question_duration_value <- data.frame(call_duration = question_end_value - question_start_value)

## simplify questions
questions$TIMESTAMP <- paste(questions$ContactDate , questions$ContactTimeEnd) ## merging date and times
edited_questions <- data.frame(CustomerID = questions$CustomerID, AgeCategory = questions$AgeCategory,
                               Gender = questions$Gender, TIMESTAMP = questions$TIMESTAMP, Activity = "Phone Call" , 
                               Theme = questions$QuestionTheme_EN , Subtheme = questions$QuestionSubtheme_EN , Topic = questions$QuestionTopic_EN)
edited_questions$TIMESTAMP <- substr(edited_questions[,4],1,19)

## simplify werkmap messages
edited_messages <- data.frame(CustomerID = werkmap_mes$CustomerID, AgeCategory = werkmap_mes$AgeCategory, 
                              Gender = werkmap_mes$Gender, TIMESTAMP = werkmap_mes$EventDateTime, Activity = "Message")
edited_messages$TIMESTAMP <- substr(edited_messages[,4],1,19)



##trying to find more info on customer ID, IPID and sessionID in the two big data sets
##length(unique(clicks_logged_in[,1]))
##length(unique(clicks_logged_in[,7]))
##length(unique(clicks_not_logged_in[,2]))
##length(unique(clicks_not_logged_in[,1]))
##length(unique(clicks_logged_in[,6]))
library(dplyr)
## merging logged in events into one single table
all_logged_in_events <- bind_rows(edited_questions, edited_messages, edited_clicks_logged_in, edited_complaints)

## Extracting the final csv file to computer
write.csv(all_logged_in_events,"C:\\Users\\sina\\Desktop\\all_logged_in_traces.csv", row.names = TRUE)
## checking unique customer IDs in logged in clicks and the merged logged in activities file.
length(unique(all_logged_in_events[,1]))
length(unique(edited_clicks_logged_in[,1]))
## simplify clicks not logged in

all_not_logged_in_events <- data.frame(CustomerID = clicks_not_logged_in$IPID , TIMESTAMP = clicks_not_logged_in$TIMESTAMP, 
                                       Activity = clicks_not_logged_in$PAGE_NAME)
all_not_logged_in_events$TIMESTAMP <- substr(all_not_logged_in_events[,2],1,19)
## Extracting the final csv file to computer
write.csv(all_not_logged_in_events,"C:\\Users\\sina\\Desktop\\all_not_logged_in_traces.csv", row.names = TRUE)
