library(lubridate)
library(bupaR)
library(daqapo)
library(dplyr)
## geting the new data sets into R

logged_in <- read.csv(file.path("C:\\Users\\sina\\Desktop\\data sets\\new2\\logged_in_final.csv"), header = TRUE)

## cleaning extra columns
logged_in <- subset(logged_in, select = c("CustomerID", "Activity", "complete","AgeCategory", "Gender", "Theme", "Subtheme", "Topic" ))
logged_in$complete<- as.POSIXct(logged_in$complete,tz=Sys.timezone())

## converting the data sets to eventlogs

logged_in <- simple_eventlog(eventlog = logged_in, case_id = "CustomerID",
                             timestamp = "complete", 
                             activity_id = "Activity", resource_id = c("Gender","AgeCategory"))
all_complaints <- filter_activity(logged_in, activities = "complaint" )

all_calls <- filter_activity(logged_in, activities = "Phone Call" )

all_messages <- filter_activity(logged_in, activities = "Message" )

library(tidyverse)

all_complaints %>%
  group_by(Theme) %>%
  summarise(n()) %>%
  top_n(10)

all_complaints %>%
  group_by(Subtheme) %>%
  summarise(n()) %>%
  top_n(10)

all_calls %>%
  group_by(Theme) %>%
  summarise(n()) %>%
  top_n(10)
all_calls %>%
  group_by(Subtheme) %>%
  summarise(n()) %>%
  top_n(10)
