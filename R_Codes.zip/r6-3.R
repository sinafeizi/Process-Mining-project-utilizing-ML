library(lubridate)
library(bupaR)
library(daqapo)
library(dplyr)
## geting the new data sets into R

logged_in <- read.csv(file.path("C:\\Users\\sina\\Desktop\\data sets\\new2\\logged_in_final.csv"), header = TRUE)

## cleaning extra columns
logged_in <- subset(logged_in, select = c("CustomerID", "Activity", "complete","AgeCategory", "Gender", "Theme", "Subtheme", "Topic" ))
logged_in$complete<- as.POSIXct(logged_in$complete,tz=Sys.timezone())

## converting the data sets to eventlogs

logged_in <- simple_eventlog(eventlog = logged_in, case_id = "CustomerID",
                             timestamp = "complete", 
                             activity_id = "Activity")

start_of_journies <- start_activities(logged_in, level = "case")
library(tidyverse)

start_of_journies %>%
  group_by(Activity) %>%
  summarise(n()) %>%
  top_n(20)
new_sample <- filter_time_period(logged_in, interval = ymd(c(20151001, 20151002)), filter_method = "start")
trace_explorer(new_sample, coverage = 0.01)

idle_time(logged_in, level = "case" )
expensive_start <- filter_trim(logged_in, start_activities = c("Message","Phone Call","complaint"))
new_sample2 <- filter_time_period(expensive_start, interval = ymd(c(20151001, 20151002)), filter_method = "start")
trace_explorer(new_sample, coverage = 0.02)
new_sample3 <- filter_activity_frequency(new_sample2, percentage = 0.65, reverse = F)

process_map(new_sample3, type_nodes = frequency("relative_case"))
